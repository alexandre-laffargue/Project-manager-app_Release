<template>
  <div class="chronologie-page">
    <h1>Chronologie</h1>
    <p>Vue de la chronologie (Gantt) — contenu à implémenter.</p>
    <div class="chronologie-placeholder">
      <!-- Placeholder: remplacer par une vraie implémentation Gantt plus tard -->
      <p>Affichage des tâches dans le temps (bientôt).</p>
    </div>
  </div>
</template>

<script setup>
// Future: importer et afficher des données de sprints/issues pour le Gantt
</script>

<style scoped>
.chronologie-page {
  margin-left: 220px;
  padding: 24px;
}
.chronologie-placeholder {
  margin-top: 1rem;
  padding: 1rem;
  background: #f8fafc;
  border: 1px dashed #cbd5e1;
}
</style>
