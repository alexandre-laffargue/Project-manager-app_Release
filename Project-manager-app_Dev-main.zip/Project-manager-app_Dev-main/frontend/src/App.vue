<template>
  <!-- The router will render the MainLayout or individual pages here -->
  <router-view />
</template>

<style scoped>
/* global app styles can go here if needed */
</style>
