export default {
  plugins: {
    // Utilisation du plugin PostCSS spécifique à Tailwind
    '@tailwindcss/postcss': {},
    // Autoprefixer est toujours utile
    autoprefixer: {},
  },
}
